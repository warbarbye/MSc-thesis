# Konspekt pracy

## Wprowadzenie (5p)

- motywacja

## Optymalizacja (5p)

- Historia pojęcia

- Definicja zadania optymalizacji

- Taksonomia metod optymalizacyjnych

## Metaheurystyki (15p)

- Historia i definicja pojęcia

- Porównywanie/testowanie metod

- Metaheurystyki populacyjne

## Adaptacja macierzy kowariancji (20p)

- Strategie ewolucyjne

- EDA
- DES
- CMA

## Modyfikacja reguły macierzy kowariancji (15p)

- Ledoit-Wolf, etc.

- todo

- Nasza modyfikacja

## Porównanie reguł macierzy kowariancji

- omówienie benchmarków (kryteria oceny, etc.)

- Porównanie

## Koniec (5p)

$$\sum p = 65 $$
